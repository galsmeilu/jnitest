/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
import com.jniwrapper.win32.ui.Wnd;

import java.util.List;

/**
 * This sample prints out list of running window applications. 
 *
 * @author Vladimir Kondrashchenko
 */
public class GetApplicationWindowsSample
{
    public static void main(String[] args)
    {
        List list = com.jniwrapper.win32.process.Process.getApplicationWindows();
        for (int i = 0; i < list.size(); i++)
        {
            Wnd wnd = (Wnd)list.get(i);
            System.out.println(wnd.getProcessId() + "  " + wnd.getWindowText());
        }
    }
}