/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
import com.jniwrapper.win32.ui.dialogs.SelectFolderDialog;

/**
 * This sample demonstrates how to work with {@link SelectFolderDialog}.
 *
 * @author Serge Piletsky
 */
public class SelectFolderDialogSample
{
    public static void main(String[] args)
    {
        SelectFolderDialog dialog = new SelectFolderDialog("Select folder");
        dialog.setFolder("C:\\");
        dialog.getOptions().setShowNetworkFolders(true);
        final boolean result = dialog.execute();
        System.out.println("result = " + result);
        if (result)
        {
            final String directory = dialog.getFolder();
            System.out.println("Selected folder = " + directory);
        }
    }
}