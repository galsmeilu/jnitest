/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
import com.jniwrapper.win32.hook.IdleTracker;
import com.jniwrapper.win32.hook.IdleTrackerListener;

/**
 * This sample demonstrates to track user idleness using hte IdleTracker class.
 *
 * @author Vladimir Kondrashchenko
 */
public class IdleTrackerSample
{

    public static void main(String[] args)
    {
        IdleTracker idle = new IdleTracker(2000);
        idle.addListener(new IdleTrackerListener()
        {
            public void timeoutElapsed()
            {
                System.out.println("Idle tracker listener...");
            }
        });
        idle.start();
    }
}