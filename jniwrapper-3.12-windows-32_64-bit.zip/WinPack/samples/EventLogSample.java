/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
import com.jniwrapper.win32.system.eventlog.EventLog;
import com.jniwrapper.win32.system.eventlog.EventLogMessage;

import java.util.List;

/**
 * This sample prints out all messages from the
 * "Application" event log.
 *
 * @author Vladimir Kondrashchenko
 */
public class EventLogSample
{
    public static void main(String[] args)
    {
        EventLog eventLog = new EventLog("Application");
        List messages = eventLog.getMessages();
        for (int i = 0; i < messages.size(); i++)
        {
            EventLogMessage eventLogMessage = (EventLogMessage)messages.get(i);
            System.out.println(eventLogMessage.getRecordNumber() + "\t" + eventLogMessage.getDate());
        }
    }
}