/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.ui;

// TODO [Sanders]: Find a better name.
public interface WindowMessageListenerEx extends WindowMessageListener
{
    // TODO [Sanders]: Find better name and document.
    public boolean isCallWindowProc(WindowMessage message);
}