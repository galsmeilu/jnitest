/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.shell;

/**
 * Defines interface for tray icon listener classes.
 * 
 * @author Alexander Evsukov
 */
public interface TrayIconListener
{
    /**
     * 
     * @param message is a window message. Can be one of the following:
     * WM_MOUSEMOVE, WM_LBUTTONDOWN, WM_LBUTTONUP, WM_LBUTTONDBLCLK,
     * WM_RBUTTONDOWN, WM_RBUTTONUP, WM_RBUTTONDBLCLK, WM_MBUTTONDOWN,
     * WM_MBUTTONUP, WM_MBUTTONDBLCLK, WM_MOUSELEAVE, WM_MOUSEHOVER
     * @param x the x-coordinate of the cursor position when an event occurred.
     * @param y the y-coordinate of the cursor position when an event occurred.
     */
    public void trayActionPerformed(long message, int x, int y);
}