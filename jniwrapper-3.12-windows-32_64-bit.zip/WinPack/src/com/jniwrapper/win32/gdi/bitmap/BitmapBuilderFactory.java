/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.gdi.bitmap;

import java.awt.image.BufferedImage;

public interface BitmapBuilderFactory
{
    BitmapBuilder createBuilder(BufferedImage bufferedImage);
}