package com.jniwrapper.win32.gdi;

import com.jniwrapper.*;

/**
 * @author Vladimir Ikryanov
 */
public class EnumFamCallBack extends Callback {

    private Int retVal = new Int();
    private LogFont logFont = new LogFont();
    private Pointer logFontPtr = new Pointer(logFont);
    private TextMetric textMetric = new TextMetric();
    private Pointer textMetricPtr = new Pointer(textMetric);
    private UInt32 fontType = new UInt32();
    private Int32 lparam = new Int32();

    public EnumFamCallBack() {
        init(new Parameter[] {
                logFontPtr, textMetricPtr, fontType, lparam
        }, retVal);
    }

    public void callback() {
        System.out.println("EnumFamCallBack.callback");
    }
}
