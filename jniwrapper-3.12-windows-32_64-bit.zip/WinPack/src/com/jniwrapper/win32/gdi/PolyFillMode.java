/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.gdi;

import com.jniwrapper.util.EnumItem;

/**
 * PolyFillMode class represents EnumItemeration of poly fill modes.
 *
 * @author Serge Piletsky
 */
public class PolyFillMode extends EnumItem
{
    public static final PolyFillMode ALTERNATE = new PolyFillMode(1);
    public static final PolyFillMode WINDING = new PolyFillMode(2);

    private PolyFillMode(int value)
    {
        super(value);
    }
}