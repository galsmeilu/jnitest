package com.jniwrapper.win32.gdi;

import com.jniwrapper.*;

/**
 * @author Vladimir Ikryanov
 */
public class TextMetric extends Structure {

    private LongInt tmHeight = new LongInt();
    private LongInt tmAscent = new LongInt();
    private LongInt tmDescent = new LongInt();
    private LongInt tmInternalLeading = new LongInt();
    private LongInt tmExternalLeading = new LongInt();
    private LongInt tmAveCharWidth = new LongInt();
    private LongInt tmMaxCharWidth = new LongInt();
    private LongInt tmWeight = new LongInt();
    private LongInt tmOverhang = new LongInt();
    private LongInt tmDigitizedAspectX = new LongInt();
    private LongInt tmDigitizedAspectY = new LongInt();
    private Char tmFirsprivate = new Char();
    private Char tmLasprivate = new Char();
    private Char tmDefaulprivate = new Char();
    private Char tmBreakChar = new Char();
    private Int8 tmItalic = new Int8();
    private Int8 tmUnderlined = new Int8();
    private Int8 tmStruckOut = new Int8();
    private Int8 tmPitchAndFamily = new Int8();
    private Int8 tmCharSet = new Int8();

    public TextMetric() {
        init(new Parameter[]{
                tmHeight,
                tmAscent,
                tmDescent,
                tmInternalLeading,
                tmExternalLeading,
                tmAveCharWidth,
                tmMaxCharWidth,
                tmWeight,
                tmOverhang,
                tmDigitizedAspectX,
                tmDigitizedAspectY,
                tmFirsprivate,
                tmLasprivate,
                tmDefaulprivate,
                tmBreakChar,
                tmItalic,
                tmUnderlined,
                tmStruckOut,
                tmPitchAndFamily,
                tmCharSet
        });
    }
}
