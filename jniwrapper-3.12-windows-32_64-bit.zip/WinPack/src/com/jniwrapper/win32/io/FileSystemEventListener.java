/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.io;

import java.util.EventListener;

/**
 * An interface for listening for file system events.
 *
 * @author Serge Piletsky
 */
public interface FileSystemEventListener extends EventListener
{
    public void handle(FileSystemEvent event);
}