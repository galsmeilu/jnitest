/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.hook;

/**
 * This class describes events of the {@link
 * com.jniwrapper.win32.hook.Hook.Descriptor#FOREGROUNDIDLE} hook.
 * 
 * @author Serge Piletsky
 */
public class ForegroungIdleEvent extends HookEventObject
{
    public ForegroungIdleEvent(Object source)
    {
        super(source);
    }
}