/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.hook.data;

import com.jniwrapper.Parameter;
import com.jniwrapper.Int;
import com.jniwrapper.win32.IntPtr;

class ShellHookData extends AbstractHookData
{
    private Int code = new Int();
    private IntPtr wParam = new IntPtr();
    private IntPtr lParam = new IntPtr();

    ShellHookData()
    {
        init(new Parameter[]{_hookHandle, _syncronous, _eventDescriptor, code, wParam, lParam}, (short) 1);
    }

    long getCode()
    {
        return code.getValue();
    }

    long getWParam()
    {
        return wParam.getValue();
    }

    long getLParam()
    {
        return lParam.getValue();
    }
}