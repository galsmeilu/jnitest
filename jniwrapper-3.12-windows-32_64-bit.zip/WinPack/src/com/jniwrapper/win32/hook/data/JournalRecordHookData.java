/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.hook.data;

import com.jniwrapper.Int;
import com.jniwrapper.Parameter;

class JournalRecordHookData extends AbstractHookData
{
    private Int code = new Int();
    private EventMessageStructure eventMessage = new EventMessageStructure();

    public JournalRecordHookData()
    {
        init(new Parameter[]{_hookHandle, _syncronous, _eventDescriptor, code, eventMessage}, (short) 1);
    }

    long getCode()
    {
        return code.getValue();
    }

    EventMessageStructure getEventMessage()
    {
        return eventMessage;
    }
}