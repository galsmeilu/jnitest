/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.hook.data;

import com.jniwrapper.Parameter;

/**
 * @author Serge Piletsky
 */
class ForegroungIdleHookData extends AbstractHookData
{
    public ForegroungIdleHookData()
    {
        init(new Parameter[]{_hookHandle, _syncronous, _eventDescriptor}, (short) 1);
    }
}