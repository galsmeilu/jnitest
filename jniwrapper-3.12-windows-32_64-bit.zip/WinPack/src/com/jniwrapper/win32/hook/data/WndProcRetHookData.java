/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.hook.data;

import com.jniwrapper.Parameter;
import com.jniwrapper.win32.IntPtr;

/**
 * @author Serge Piletsky
 */
class WndProcRetHookData extends AbstractHookData
{
    private IntPtr wParam = new IntPtr();
    private CWndProcRetStructure cwpRetStruct = new CWndProcRetStructure();

    WndProcRetHookData()
    {
        init(new Parameter[]{_hookHandle, _syncronous, _eventDescriptor, wParam, cwpRetStruct}, (short) 1);
    }

    long getwParam()
    {
        return wParam.getValue();
    }

    CWndProcRetStructure getCwpRetStruct()
    {
        return cwpRetStruct;
    }
}