/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.hook.data;

import com.jniwrapper.Parameter;
import com.jniwrapper.UInt32;
import com.jniwrapper.win32.Msg;
import com.jniwrapper.win32.IntPtr;

class GetMsgHookData extends AbstractHookData
{
    private IntPtr wParam = new IntPtr();
    private Msg msg = new Msg();

    GetMsgHookData()
    {
        init(new Parameter[]{_hookHandle, _syncronous, _eventDescriptor, wParam, msg}, (short) 1);
    }

    long getWParam()
    {
        return wParam.getValue();
    }

    Msg getMsg()
    {
        return msg;
    }
}