/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.hook;

import java.util.EventListener;

/**
 * This class is a listener of the mouse and keyboard idle timeout events.
 *
 * @see <code>com.jniwrapper.win32.hook.IdleTracker</code>
 *
 * @author Vladimir Kondrashchenko
 */
public interface IdleTrackerListener extends EventListener
{
    public void timeoutElapsed();
}