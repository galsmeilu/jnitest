/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.hook;

/**
 * An abstract adapter class for receiving CBT Hook events.
 */
public class CBTHookAdapter implements CBTHookListener
{
    public void activate(CBTEvent.Activate event)
    {
    }

    public void clickSkipped(CBTEvent.ClickSkipped event)
    {
    }

    public void createWnd(CBTEvent.CreateWnd event)
    {
    }

    public void destroyWnd(CBTEvent.DestroyWnd event)
    {
    }

    public void keySkipped(CBTEvent.KeySkipped event)
    {
    }

    public void minMax(CBTEvent.MinMax event)
    {
    }

    public void moveSize(CBTEvent.MoveSize event)
    {
    }

    public void qs(CBTEvent.QS event)
    {
    }

    public void setFocus(CBTEvent.SetFocus event)
    {
    }

    public void sysCommand(CBTEvent.SysCommand event)
    {
    }
}