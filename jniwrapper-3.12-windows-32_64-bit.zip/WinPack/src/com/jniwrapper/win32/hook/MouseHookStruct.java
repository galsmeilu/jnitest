package com.jniwrapper.win32.hook;

import com.jniwrapper.Parameter;
import com.jniwrapper.Pointer;
import com.jniwrapper.Structure;
import com.jniwrapper.UInt32;
import com.jniwrapper.win32.Point;

/**
 * This class represents the wrapper for <code>MSLLHOOKSTRUCT</code> native structure.
 */
class MouseHookStruct extends Structure
{
    private Point point = new Point();
    private UInt32 mouseData = new UInt32();
    private UInt32 flags = new UInt32();
    private UInt32 time = new UInt32();
    private Pointer.Void extraInfo = new Pointer.Void();

    public MouseHookStruct()
    {
        init(new Parameter[]{point, mouseData, flags, time, extraInfo}, (short) 8);
    }

    public Object clone()
    {
        MouseHookStruct clone = new MouseHookStruct();
        clone.initFrom(this);
        return clone;
    }

    public Point getPoint()
    {
        return point;
    }

    public UInt32 getMouseData()
    {
        return mouseData;
    }

    public UInt32 getFlags()
    {
        return flags;
    }

    public UInt32 getTime()
    {
        return time;
    }

    public Pointer.Void getExtraInfo()
    {
        return extraInfo;
    }
}
