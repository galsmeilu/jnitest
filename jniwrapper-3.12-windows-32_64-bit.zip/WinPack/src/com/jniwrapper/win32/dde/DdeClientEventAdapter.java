/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.dde;

/**
 * An abstract adapter class for processing DDE client events.
 *
 * @author Vladimir Kondrashchenko
 */
public abstract class DdeClientEventAdapter extends DdeEventAdapter implements DdeClientEventHandler
{
    public void error(int errorCode)
    {
    }

    public DdeResponse itemChanged(DdeItem item, byte[] data)
    {
        return null;
    }

    public void asyncActionComplete(DdeItem item, byte[] data, long transactionID)
    {
    }
}