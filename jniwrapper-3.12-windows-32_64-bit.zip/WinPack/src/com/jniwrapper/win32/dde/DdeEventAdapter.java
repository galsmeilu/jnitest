/*
 * Copyright (c) 2000-2009 TeamDev Ltd. All rights reserved.
 * TeamDev PROPRIETARY and CONFIDENTIAL.
 * Use is subject to license terms.
 */
package com.jniwrapper.win32.dde;

/**
 * An abstract adapter class for processing DDE events that are common for clients and services.
 *
 * @author Vladimir Kondrashchenko
 */
abstract class DdeEventAdapter implements DdeEventHandler
{
    public void disconnect(boolean sameApplication)
    {
    }

    public void serviceRegister(String service, String instanceName)
    {
    }

    public void serviceUnregister(String service, String instanceName)
    {
    }
}